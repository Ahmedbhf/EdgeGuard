/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "app_runtime.h"
#include "tasks.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
osThreadId acquisitionTaskHandle;
osThreadId aiTaskHandle;
osThreadId uartTaskHandle;
osThreadId ledTaskHandle;
osThreadId anomalyTaskHandle;
osThreadId buzzerTaskHandle;

static StaticTask_t defaultTaskControlBlock;
static StackType_t defaultTaskStack[128];
static StaticTask_t acquisitionTaskControlBlock;
static StackType_t acquisitionTaskStack[256];
static StaticTask_t aiTaskControlBlock;
static StackType_t aiTaskStack[512];
static StaticTask_t uartTaskControlBlock;
static StackType_t uartTaskStack[256];
static StaticTask_t ledTaskControlBlock;
static StackType_t ledTaskStack[128];
static StaticTask_t anomalyTaskControlBlock;
static StackType_t anomalyTaskStack[128];
static StaticTask_t buzzerTaskControlBlock;
static StackType_t buzzerTaskStack[128];

/* USER CODE END Variables */
osThreadId defaultTaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */

  /* USER CODE BEGIN RTOS_THREADS */
  osThreadStaticDef(acquisitionTask, acquisition_task, osPriorityHigh, 0, 256, acquisitionTaskStack, &acquisitionTaskControlBlock);
  acquisitionTaskHandle = osThreadCreate(osThread(acquisitionTask), NULL);

  osThreadStaticDef(aiTask, ai_task, osPriorityNormal, 0, 512, aiTaskStack, &aiTaskControlBlock);
  aiTaskHandle = osThreadCreate(osThread(aiTask), NULL);

  osThreadStaticDef(uartTask, uart_task, osPriorityBelowNormal, 0, 256, uartTaskStack, &uartTaskControlBlock);
  uartTaskHandle = osThreadCreate(osThread(uartTask), NULL);

  osThreadStaticDef(ledTask, led_task, osPriorityLow, 0, 128, ledTaskStack, &ledTaskControlBlock);
  ledTaskHandle = osThreadCreate(osThread(ledTask), NULL);

  osThreadStaticDef(anomalyTask, anomaly_task, osPriorityBelowNormal, 0, 128, anomalyTaskStack, &anomalyTaskControlBlock);
  anomalyTaskHandle = osThreadCreate(osThread(anomalyTask), NULL);

  osThreadStaticDef(buzzerTask, buzzer_task, osPriorityLow, 0, 128, buzzerTaskStack, &buzzerTaskControlBlock);
  buzzerTaskHandle = osThreadCreate(osThread(buzzerTask), NULL);
  /* USER CODE END RTOS_THREADS */

}


/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */
