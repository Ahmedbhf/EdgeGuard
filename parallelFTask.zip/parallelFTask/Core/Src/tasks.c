//Includes -----------
#include "tasks.h"
#include "anomaly.h"
#include "app_runtime.h"
#include "buzzer.h"
#include "cmsis_os.h"
#include "control.h"
#include "main.h"
#include "task.h"

//Defines -------
#define ANOMALY_TASK_DELAY_MS 100U
#define BUZZER_TASK_DELAY_MS 50U


/**
 * @brief Sensor acquisition task.
 *
 * Waits for a notification (100 Hz timer trigger) and processes
 * sensor acquisition when the system is enabled.
 */
void acquisition_task(void const * argument)
{
    (void)argument;

    for (;;)
    {
        (void)ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (system_is_enabled())
        {
            app_acquisition_process_pending();
        }
    }
}

/**
 * @brief AI processing task.
 *
 * Waits for notifications and runs AI processing pipeline
 * when the system is enabled.
 */
void ai_task(void const * argument)
{
    (void)argument;

    for (;;)
    {
        (void)ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (system_is_enabled())
        {
            app_ai_process_pending();
        }
    }
}

/**
 * @brief UART communication task.
 *
 * Waits for UART-related events and handles commands
 * and telemetry processing when enabled.
 */
void uart_task(void const * argument)
{
    (void)argument;

    for (;;)
    {
        (void)ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (system_is_enabled())
        {
            app_uart_process_pending();
        }
    }
}

/**
 * @brief LED management task.
 *
 * Continuously updates LED state based on system status.
 */
void led_task(void const * argument)
{
    (void)argument;

    for (;;)
    {
        app_led_update();
    }
}

/**
 * @brief Anomaly monitoring task.
 *
 * Periodically updates anomaly detection logic.
 */
void anomaly_task(void const * argument)
{
    (void)argument;

    for (;;)
    {
        if (system_is_enabled())
        {
            anomaly_update(&system_data);
        }

        osDelay(ANOMALY_TASK_DELAY_MS);
    }
}

/**
 * @brief Buzzer control task.
 *
 * Updates buzzer state based on system status or turns it off
 * when the system is disabled.
 */
void buzzer_task(void const * argument)
{
    (void)argument;

    for (;;)
    {
        if (system_is_enabled())
        {
            buzzer_update(&system_data);
        }
        else
        {
            buzzer_off();
        }

        osDelay(BUZZER_TASK_DELAY_MS);
    }
}
