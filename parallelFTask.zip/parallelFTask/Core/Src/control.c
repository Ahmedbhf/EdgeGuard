//Includes------
#include "control.h"

void control_init(system_data_t *data)
{
    data->enabled = 1U;
}

uint8_t control_update_button(system_data_t *data, uint32_t now_ms)
{
    (void)data;
    (void)now_ms;

    /* PC13/B1 is intentionally disabled; the runtime stays enabled unless
       another control path changes the system state. */
    return 0U;
}

uint8_t system_is_enabled(void)
{
    return system_data.enabled;
}
