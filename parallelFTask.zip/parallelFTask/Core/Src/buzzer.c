//Includes -------
#include "buzzer.h"
#include "main.h"

//Functions ------

/**
 * @brief Control buzzer state based on system status.
 * Activates buzzer only when system is enabled and in CRITICAL state.
 * @param data Pointer to system data structure.
 */
void buzzer_update(const system_data_t *data)
{
    GPIO_PinState pin_state = GPIO_PIN_RESET;

    if ((data->enabled != 0U) && (data->state == SYSTEM_STATE_CRITICAL))
    {
        pin_state = GPIO_PIN_SET;
    }

    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, pin_state);
}

/**
 * @brief Turn off the buzzer.
 * Forces buzzer GPIO to LOW state.
 */
void buzzer_off(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
}
