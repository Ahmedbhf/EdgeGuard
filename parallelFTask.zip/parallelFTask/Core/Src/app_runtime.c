// Includes
#include "app_runtime.h"
#include "buzzer.h"
#include "control.h"
#include "i2c.h"
#include "main.h"
#include "arm_math.h"
#include "cmsis_os.h"
#include "task.h"
#include "NanoEdgeAI.h"
#include "classification.h"
#include "classification_data_params.h"
#include "model_d_scaler.h"
#include "mpu.h"
#include "mlx90614.h"
#include "tim.h"
#include "uart_format.h"
#include "usart.h"
#include <math.h>

//typedef
typedef enum
{
    LED_STATE_NORMAL = 0,
    LED_STATE_ANOMALY,
    LED_STATE_MLX_ERROR,
    LED_STATE_NEAI_ERROR,
    LED_STATE_MPU_ERROR
} led_state_t;
system_data_t system_data = {
    .similarity = 0.0f,
    .temperature = 0.0f,
    .inference_time_us = 0U,
    .state = SYSTEM_STATE_NORMAL,
    .enabled = 1U,
    .fault_class = SYSTEM_CLASS_MOTOR_OFF
};

// Defines
#define BUFFER_SIZE 256
#define AXIS 3
#define TOTAL_VALUES (BUFFER_SIZE * AXIS)
#define CLASSIFICATION_FEATURE_COUNT AI_CLASSIFICATION_IN_1_SIZE
#define CLASSIFICATION_OUTPUT_COUNT AI_CLASSIFICATION_OUT_1_SIZE
#define FFT_FEATURE_BINS ((BUFFER_SIZE / 2U) + 1U)
#define LEARN_NB_ITERATION 50
#define TELEMETRY_TEMP_DIVIDER 5U
#define MPU_FIXED_SAMPLE_COUNT 50U

#if (CLASSIFICATION_FEATURE_COUNT != (AXIS * FFT_FEATURE_BINS))
#error "Classification feature extractor must match CubeAI model input size."
#endif

#if (EDGEGUARD_MODEL_D_FEATURE_COUNT != CLASSIFICATION_FEATURE_COUNT)
#define CLASSIFICATION_USE_EXTERNAL_SCALER 1U
#else
#define CLASSIFICATION_USE_EXTERNAL_SCALER 0U
#endif

//Variables --------
extern osThreadId acquisitionTaskHandle;
extern osThreadId aiTaskHandle;
extern osThreadId uartTaskHandle;

static int16_t sample_buffers[2][TOTAL_VALUES];
static float ai_input[TOTAL_VALUES];
AI_ALIGNED(4) static uint8_t classification_activations[AI_CLASSIFICATION_DATA_ACTIVATIONS_SIZE];
static ai_handle classification_network = AI_HANDLE_NULL;
static arm_rfft_fast_instance_f32 fft_instance;
static float fft_input[BUFFER_SIZE];
static float fft_output[BUFFER_SIZE];
static float classification_features[CLASSIFICATION_FEATURE_COUNT];
static float classification_probabilities[CLASSIFICATION_OUTPUT_COUNT];
static volatile uint32_t sample_due = 0;
static volatile uint32_t uart_due = 0;
static volatile uint8_t relearn_request = 0;
static volatile uint8_t uart_command_pending = 0;
static volatile uint8_t uart_busy = 0;
static volatile uint32_t sample_overrun_count = 0;
static volatile uint32_t uart_drop_count = 0;
static uint16_t write_index = 0;
static uint16_t relearn_iteration = 0;
static uint8_t fill_buffer = 0;
static uint8_t ready_buffer = 0xFF;
static uint8_t window_ready = 0;
static uint8_t relearn_active = 0;
static uint8_t model_ready = 0;
static uint8_t mlx_error = 0;
static uint8_t neai_error = 0;
static uint8_t classification_error = 0;
static uint8_t mpu_error = 0;
static volatile uint8_t uart_command = 0;
static uint8_t uart_rx_byte = 0;
static uint8_t uart_tx_buffer[128];
static const char product_id[] = "002E0032-42325004-20333839";
static float temperature_moteur_c = 0.0f;
static float temperature_ambiante_c = 0.0f;
static int16_t last_x = 0;
static int16_t last_y = 0;
static int16_t last_z = 0;
static uint16_t mpu_fixed_count = 0;
static uint8_t mpu_sample_valid = 0;
static uint8_t telemetry_tick_divider = 0;
static volatile led_state_t led_state = LED_STATE_NORMAL;

void stm32_get_product_id(char *buf, size_t len);
static void inference_timer_init(void);
static uint32_t measure_elapsed_us(uint32_t start_cycles, uint32_t end_cycles);
static uint8_t consume_counter(volatile uint32_t *counter);
static void notify_task(osThreadId task_handle);
static void notify_task_from_isr(osThreadId task_handle);
static int32_t centi_celsius_from_float(float temp_c);
static void read_sensors(void);
static void temperature_update(void);
static void process_ai(void);
static void classification_init(void);
static uint8_t classify_window(const float *window);
static void extract_classification_features(const float *window, float *features);
static void handle_uart(void);
static void trigger_relearn(void);
static void update_led_state(void);
static void clear_pending_work(void);


//Functions------

/**
 * @brief Initialize full application runtime and peripherals.
 * Configures sensors, AI models, timers, UART, and system state.
 */
void app_runtime_init(void)
{
    MPU_ConfigTypeDef my_mpu_config;

    control_init(&system_data);
    buzzer_off();
    stm32_get_product_id(product_id, sizeof(product_id));
    MPU6050_Init(&hi2c1);

    my_mpu_config.Accel_Full_Scale = AFS_SEL_4g;
    my_mpu_config.ClockSource = Internal_8MHz;
    my_mpu_config.CONFIG_DLPF = DLPF_184A_188G_Hz;
    my_mpu_config.Gyro_Full_Scale = FS_SEL_500;
    my_mpu_config.Sleep_Mode_Bit = 0;
    MPU6050_Config(&my_mpu_config);

    if (MLX90614_Init() != 1U)
    {
        mlx_error = 1U;
    }

    if (neai_anomalydetection_init(0) != NEAI_OK)
    {
        neai_error = 1U;
    }

    inference_timer_init();
    classification_init();

    temperature_update();

    HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LD_B_GPIO_Port, LD_B_Pin, GPIO_PIN_SET);
    update_led_state();
}



/**
 * @brief Process pending sensor acquisitions (100 Hz).
 * Consumes acquisition events and reads sensors.
 */
void app_acquisition_process_pending(void)
{
    while (consume_counter(&sample_due))
    {
        read_sensors();
    }
}

/**
 * @brief Execute AI processing pipeline.
 * Handles inference, relearning, and window processing.
 */
void app_ai_process_pending(void)
{
    process_ai();

    while (((relearn_request != 0U) || (window_ready != 0U)) && system_is_enabled())
    {
        process_ai();
    }
}

/**
 * @brief Process UART communication tasks.
 * Handles commands, telemetry transmission, and scheduled UART events.
 */
void app_uart_process_pending(void)
{
    handle_uart();

    while (((uart_command_pending != 0U) || (uart_due != 0U)) && system_is_enabled())
    {
        handle_uart();
    }
}

/**
 * @brief Update LED state based on system status.
 * Indicates errors, anomalies, and normal operation modes.
 */
void app_led_update(void)
{
    if (!system_is_enabled())
    {
        HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LD_B_GPIO_Port, LD_B_Pin, GPIO_PIN_RESET);
        osDelay(100);
        return;
    }

    switch (led_state)
    {
        case LED_STATE_MLX_ERROR:
            HAL_GPIO_TogglePin(LD_R_GPIO_Port, LD_R_Pin);
            HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_RESET);
            osDelay(500);
            break;

        case LED_STATE_NEAI_ERROR:
            HAL_GPIO_TogglePin(LD_R_GPIO_Port, LD_R_Pin);
            HAL_GPIO_TogglePin(LD_G_GPIO_Port, LD_G_Pin);
            osDelay(500);
            break;

        case LED_STATE_MPU_ERROR:
            HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
            HAL_GPIO_TogglePin(LD_G_GPIO_Port, LD_G_Pin);
            osDelay(500);
            break;

        case LED_STATE_ANOMALY:
            HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_RESET);
            osDelay(100);
            break;

        case LED_STATE_NORMAL:
        default:
            HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_SET);
            osDelay(100);
            break;
    }
}

/**
 * @brief Atomically consume one event from an ISR-updated counter.
 * @param counter Pointer to event counter.
 * @return 1 if an event was consumed, 0 otherwise.
 */
static uint8_t consume_counter(volatile uint32_t *counter)
{
    uint8_t has_event = 0;

    __disable_irq();
    if (*counter > 0U)
    {
        (*counter)--;
        has_event = 1;
    }
    __enable_irq();

    return has_event;
}

/**
 * @brief  Notify a FreeRTOS task from normal task context.
 * This function sends a "direct-to-task notification" to the given task.
 * It is used as a lightweight signaling mechanism instead of semaphores.
 * @param  task_handle  Handle of the task to notify. Must not be NULL.
 */
static void notify_task(osThreadId task_handle)
{
    if (task_handle != NULL)
    {
        xTaskNotifyGive((TaskHandle_t)task_handle);
    }
}

/**
 * @brief  Notify a FreeRTOS task from ISR context.
 * This function safely notifies a task from an interrupt service routine
 * using the FreeRTOS ISR-safe API. If a higher priority task is woken,
 * a context switch is requested at ISR exit.
 * @param  task_handle  Handle of the task to notify. Must not be NULL.
 */
static void notify_task_from_isr(osThreadId task_handle)
{
    BaseType_t higher_priority_task_woken = pdFALSE;

    if (task_handle != NULL)
    {
        vTaskNotifyGiveFromISR((TaskHandle_t)task_handle, &higher_priority_task_woken);
        portYIELD_FROM_ISR(higher_priority_task_woken);
    }
}

/**
 * @brief Convert °C float to centi-degrees (°C × 100) with rounding.
 * @param temp_c Temperature in °C.
 * @return Temperature in centi-°C as int32_t.
 */
static int32_t centi_celsius_from_float(float temp_c)
{
    float scaled = temp_c * 100.0f;
    return (int32_t)(scaled >= 0.0f ? (scaled + 0.5f) : (scaled - 0.5f));
}

/**
 * @brief Read MPU6050 sensor data and update buffers/state machine.
 * Handles acceleration sampling, error detection (stuck samples),
 * LED status update, and circular buffer filling for AI processing.
 */
static void read_sensors(void)
{
    ScaledData_Def sample;
    uint8_t current_fill_buffer = fill_buffer;
    int16_t current_x;
    int16_t current_y;
    int16_t current_z;

    if (!MPU6050_Get_Accel_Scale(&sample))
    {
        mpu_error = 1U;
        mpu_fixed_count = 0U;
        mpu_sample_valid = 0U;
        update_led_state();
        return;
    }

    current_x = (int16_t)sample.x;
    current_y = (int16_t)sample.y;
    current_z = (int16_t)sample.z;

    if ((mpu_sample_valid != 0U) &&
        (current_x == last_x) &&
        (current_y == last_y) &&
        (current_z == last_z))
    {
        if (mpu_fixed_count < MPU_FIXED_SAMPLE_COUNT)
        {
            mpu_fixed_count++;
        }
    }
    else
    {
        mpu_fixed_count = 0U;
        mpu_sample_valid = 1U;
    }

    mpu_error = (uint8_t)(mpu_fixed_count >= MPU_FIXED_SAMPLE_COUNT);
    last_x = current_x;
    last_y = current_y;
    last_z = current_z;
    update_led_state();

    sample_buffers[current_fill_buffer][write_index++] = last_x;
    sample_buffers[current_fill_buffer][write_index++] = last_y;
    sample_buffers[current_fill_buffer][write_index++] = last_z;

    if (write_index >= TOTAL_VALUES)
    {
        if (window_ready)
        {
            sample_overrun_count++;
            write_index = 0;
        }
        else
        {
            ready_buffer = current_fill_buffer;
            window_ready = 1;
            fill_buffer ^= 1U;
            write_index = 0;
            notify_task(aiTaskHandle);
        }
    }
}

/**
 * @brief Initialize DWT cycle counter for inference timing.
 * Enables CPU cycle counter for high-resolution performance measurement.
 */
static void inference_timer_init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0U;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

/**
 * @brief Convert CPU cycles to elapsed time in microseconds.
 * @param start_cycles Start DWT cycle count.
 * @param end_cycles   End DWT cycle count.
 * @return Elapsed time in µs.
 */
static uint32_t measure_elapsed_us(uint32_t start_cycles, uint32_t end_cycles)
{
    uint32_t elapsed_cycles = end_cycles - start_cycles;

    if (SystemCoreClock == 0U)
    {
        return 0U;
    }

    return (uint32_t)((((uint64_t)elapsed_cycles) * 1000000ULL) / (uint64_t)SystemCoreClock);
}

/**
 * @brief Read and update MLX90614 temperatures.
 * Updates motor and ambient temperature values, and sets error flag
 * if sensor readings are invalid (NaN).
 */
static void temperature_update(void)
{
    float object_temp = MLX90614_readObjectTempC();
    float ambient_temp = MLX90614_readAmbientTempC();

    if (!isnan(object_temp))
    {
        temperature_moteur_c = object_temp;
        system_data.temperature = object_temp;
    }

    if (!isnan(ambient_temp))
    {
        temperature_ambiante_c = ambient_temp;
    }

    mlx_error = (uint8_t)(isnan(object_temp) || isnan(ambient_temp));
    update_led_state();
}

/**
 * @brief Handle UART commands and transmission.
 * Processes incoming UART commands, triggers AI requests,
 * updates temperature periodically, and sends  data
 * via UART using DMA.
 */
static void handle_uart(void)
{
    uint8_t command = 0U;

    if (!system_is_enabled())
    {
        return;
    }

    if (uart_command_pending != 0U)
    {
        __disable_irq();
        command = uart_command;
        uart_command_pending = 0U;
        __enable_irq();

        if ((command == 'r') || (command == 'R'))
        {
            relearn_request = 1U;
            notify_task(aiTaskHandle);
        }
    }

    while (consume_counter(&uart_due))
    {
        system_data_t uart_data;
        int32_t moteur_centi;
        int32_t ambiante_centi;
        int len;

        telemetry_tick_divider++;
        if (telemetry_tick_divider >= TELEMETRY_TEMP_DIVIDER)
        {
            telemetry_tick_divider = 0U;
            temperature_update();
        }

        if (uart_busy)
        {
            uart_drop_count++;
            continue;
        }

        moteur_centi = centi_celsius_from_float(temperature_moteur_c);
        ambiante_centi = centi_celsius_from_float(temperature_ambiante_c);
        uart_data = system_data;

        len = uart_format_telemetry(uart_tx_buffer,
                                    sizeof(uart_tx_buffer),
                                    product_id,
                                    &uart_data,
                                    last_x,
                                    last_y,
                                    last_z,
                                    moteur_centi,
                                    ambiante_centi,
									relearn_active,
									relearn_iteration,
									LEARN_NB_ITERATION);

        if ((len <= 0) || (len >= (int)sizeof(uart_tx_buffer)))
        {
            continue;
        }

        uart_busy = 1U;
        if (HAL_UART_Transmit_DMA(&huart2, uart_tx_buffer, (uint16_t)len) != HAL_OK)
        {
            uart_busy = 0U;
        }
    }
}

/**
 * @brief Run AI processing pipeline (learning + inference).
 * Handles relearn requests, feeds sensor window to AI model,
 * performs learning or anomaly detection, and updates system state.
 */
static void process_ai(void)
{
    if (!system_is_enabled())
    {
        return;
    }

    if (relearn_request != 0U)
    {
        __disable_irq();
        relearn_request = 0U;
        __enable_irq();

        trigger_relearn();
    }

    if ((!window_ready) || (ready_buffer > 1U))
    {
        return;
    }

    for (int i = 0; i < TOTAL_VALUES; i++)
    {
        ai_input[i] = (float)sample_buffers[ready_buffer][i];
    }

    window_ready = 0U;

    if (relearn_active != 0U)
    {
        enum neai_state learn_status;

        learn_status = neai_anomalydetection_learn(ai_input);
        HAL_GPIO_TogglePin(LD_B_GPIO_Port, LD_B_Pin);
        relearn_iteration++;

        if ((learn_status != NEAI_OK) &&
            (learn_status != NEAI_LEARNING_IN_PROGRESS) &&
            (learn_status != NEAI_LEARNING_DONE))
        {
            relearn_active = 0U;
            neai_error = 1U;
            system_data.similarity = 0.0f;
            system_data.inference_time_us = 0U;
            system_data.fault_class = SYSTEM_CLASS_MOTOR_OFF;
            HAL_GPIO_WritePin(LD_B_GPIO_Port, LD_B_Pin, GPIO_PIN_SET);
            update_led_state();
            return;
        }

        if ((learn_status == NEAI_LEARNING_DONE) || (relearn_iteration >= LEARN_NB_ITERATION))
        {
            relearn_active = 0U;
            model_ready = 1U;
            HAL_GPIO_WritePin(LD_B_GPIO_Port, LD_B_Pin, GPIO_PIN_SET);
            update_led_state();
        }

        return;
    }

    if ((model_ready == 0U) || (neai_error != 0U))
    {
        return;
    }

    {
        uint8_t detected_similarity = 0U;

        uint32_t inference_start_cycles;
        uint32_t inference_end_cycles;
        inference_start_cycles = DWT->CYCCNT;

        enum neai_state detect_status = neai_anomalydetection_detect(ai_input, &detected_similarity);

        if (detect_status != NEAI_OK)
        {
            system_data.similarity = 0.0f;
            system_data.inference_time_us = 0U;
            neai_error = 1U;
            system_data.fault_class = SYSTEM_CLASS_MOTOR_OFF;
            update_led_state();
            return;
        }

        system_data.similarity = (float)detected_similarity;
        system_data.fault_class = classify_window(ai_input);
        inference_end_cycles = DWT->CYCCNT;
        system_data.inference_time_us =measure_elapsed_us(inference_start_cycles,inference_end_cycles);
        update_led_state();
    }
}

/**
 * @brief Initialize classification neural network.
 * Sets up FFT and creates the AI classification model instance.
 */
static void classification_init(void)
{
    const ai_handle activations[] = { classification_activations };
    const ai_handle *weights = AI_CLASSIFICATION_DATA_WEIGHTS_TABLE_GET();
    ai_error error;

    if (arm_rfft_fast_init_f32(&fft_instance, BUFFER_SIZE) != ARM_MATH_SUCCESS)
    {
        classification_error = 1U;
        return;
    }

    error = ai_classification_create_and_init(&classification_network, activations, weights);
    if (error.type != AI_ERROR_NONE)
    {
        classification_network = AI_HANDLE_NULL;
        classification_error = 1U;
    }
}

/**
 * @brief Run classification on a data window.
 * Extracts features and returns the most probable class.
 * @param window Input signal window.
 * @return Predicted class label.
 */
static uint8_t classify_window(const float *window)
{
    ai_buffer *input;
    ai_buffer *output;
    ai_i32 batch_count;
    uint8_t best_class = SYSTEM_CLASS_MOTOR_OFF;
    float best_probability = -1.0f;

    if ((classification_network == AI_HANDLE_NULL) || (classification_error != 0U))
    {
        return SYSTEM_CLASS_MOTOR_OFF;
    }

    extract_classification_features(window, classification_features);
#if CLASSIFICATION_USE_EXTERNAL_SCALER
    for (uint16_t i = 0U; i < CLASSIFICATION_FEATURE_COUNT; i++)
    {
        classification_features[i] = (classification_features[i] - EDGEGUARD_MODEL_D_FEATURE_MEAN[i]) /
                                     EDGEGUARD_MODEL_D_FEATURE_STD[i];
    }
#endif

    input = ai_classification_inputs_get(classification_network, NULL);
    output = ai_classification_outputs_get(classification_network, NULL);
    if ((input == NULL) || (output == NULL))
    {
        classification_error = 1U;
        return SYSTEM_CLASS_MOTOR_OFF;
    }

    input[0].data = AI_HANDLE_PTR(classification_features);
    output[0].data = AI_HANDLE_PTR(classification_probabilities);

    batch_count = ai_classification_run(classification_network, input, output);

    if (batch_count != 1)
    {
        classification_error = 1U;
        return SYSTEM_CLASS_MOTOR_OFF;
    }

    for (uint8_t class_id = 0U; class_id < CLASSIFICATION_OUTPUT_COUNT; class_id++)
    {
        if (classification_probabilities[class_id] > best_probability)
        {
            best_probability = classification_probabilities[class_id];
            best_class = class_id;
        }
    }

    return best_class;
}

/**
 * @brief Extract FFT-based features from signal window.
 * Computes windowed FFT magnitude features per axis.
 */
static void extract_classification_features(const float *window, float *features)
{
    for (uint8_t axis = 0U; axis < AXIS; axis++)
    {
        for (uint16_t sample = 0U; sample < BUFFER_SIZE; sample++)
        {
            float window_value = 0.5f - (0.5f * arm_cos_f32((2.0f * PI * (float)sample) / ((float)BUFFER_SIZE - 1.0f)));
            fft_input[sample] = window[(sample * AXIS) + axis] * window_value;
        }

        arm_rfft_fast_f32(&fft_instance, fft_input, fft_output, 0);

        for (uint16_t bin = 0U; bin < FFT_FEATURE_BINS; bin++)
        {
            float real;
            float imag;
            float magnitude;

            if (bin == 0U)
            {
                real = fft_output[0];
                imag = 0.0f;
            }
            else if (bin == (FFT_FEATURE_BINS - 1U))
            {
                real = fft_output[1];
                imag = 0.0f;
            }
            else
            {
                real = fft_output[2U * bin];
                imag = fft_output[(2U * bin) + 1U];
            }

            magnitude = sqrtf((real * real) + (imag * imag));
            features[(axis * FFT_FEATURE_BINS) + bin] = log1pf(magnitude);
        }
    }
}
/**
 * @brief Trigger AI model relearning sequence.
 * Resets state and enables learning mode if no error is active.
 */
static void trigger_relearn(void)
{
    if ((relearn_active != 0U) || (neai_error != 0U))
    {
        return;
    }

    relearn_active = 1U;
    relearn_iteration = 0U;
    model_ready = 0U;
    system_data.similarity = 0.0f;
    system_data.inference_time_us = 0U;
    system_data.state = SYSTEM_STATE_NORMAL;
    system_data.fault_class = SYSTEM_CLASS_MOTOR_OFF;
    HAL_GPIO_WritePin(LD_B_GPIO_Port, LD_B_Pin, GPIO_PIN_RESET);
    update_led_state();
}

 // @brief Update system LED state based on error flags.
static void update_led_state(void)
{
    if ((neai_error != 0U) || (classification_error != 0U))
    {
        led_state = LED_STATE_NEAI_ERROR;
    }
    else if (mlx_error != 0U)
    {
        led_state = LED_STATE_MLX_ERROR;
    }
    else if (mpu_error != 0U)
    {
        led_state = LED_STATE_MPU_ERROR;
    }
    else if (system_data.state != SYSTEM_STATE_NORMAL)
    {
        led_state = LED_STATE_ANOMALY;
    }
    else
    {
        led_state = LED_STATE_NORMAL;
    }
}

/**
 * @brief Clear pending system work and reset runtime flags.
 * Resets counters, buffers, and pending event flags safely.
 */
static void clear_pending_work(void)
{
    __disable_irq();
    sample_due = 0U;
    uart_due = 0U;
    relearn_request = 0U;
    uart_command_pending = 0U;
    __enable_irq();

    write_index = 0U;
    ready_buffer = 0xFF;
    window_ready = 0U;
    telemetry_tick_divider = 0U;
}

/**
 * @brief Timer callback for acquisition and UART scheduling.
 * Increments task counters and notifies FreeRTOS tasks from ISR.
 */
void app_runtime_on_timer_elapsed(TIM_HandleTypeDef *htim)
{
    if ((htim->Instance == TIM2) && system_is_enabled())
    {
        sample_due++;
        notify_task_from_isr(acquisitionTaskHandle);
    }
    else if ((htim->Instance == TIM3) && system_is_enabled())
    {
        uart_due++;
        notify_task_from_isr(uartTaskHandle);
    }
}

/**
 * @brief GPIO external interrupt callback.
 * Triggers a relearn request when the RELEARN pin is activated
 * and the system is enabled.
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if ((GPIO_Pin == RELEARN_Pin_Pin) && system_is_enabled())
    {
        relearn_request = 1U;
        notify_task_from_isr(aiTaskHandle);
    }
}

/**
 * @brief UART transmission complete callback.
 * Marks UART as available after DMA transmission completes.
 */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        uart_busy = 0U;
    }
}

/**
 * @brief UART receive complete callback.
 * Stores received command byte, restarts UART reception,
 * and notifies UART task if system is enabled.
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        uart_command = uart_rx_byte;
        uart_command_pending = 1U;
        HAL_UART_Receive_IT(&huart2, &uart_rx_byte, 1U);

        if (system_is_enabled())
        {
            notify_task_from_isr(uartTaskHandle);
        }
    }
}

/**
 * @brief Get STM32F446RET6 unique device ID as a formatted string.
 * Formats the 96-bit hardware UID into a human-readable string.
 * @param buf Output buffer.
 * @param len Buffer size.
 */
void stm32_get_product_id(char *buf, size_t len)
{
    uint32_t uid0 = HAL_GetUIDw0();
    uint32_t uid1 = HAL_GetUIDw1();
    uint32_t uid2 = HAL_GetUIDw2();

    snprintf(buf, len,
             "%08lX-%08lX-%08lX",
             (unsigned long)uid0,
             (unsigned long)uid1,
             (unsigned long)uid2);
}
