#include "uart_format.h"
#include <stdio.h>
#include <stdlib.h>

int uart_format_telemetry(uint8_t *buffer,
                          size_t buffer_size,
                          const char *product_id,
                          const system_data_t *data,
                          int16_t x,
                          int16_t y,
                          int16_t z,
                          int32_t motor_centi,
                          int32_t ambient_centi,
						  uint8_t relearn_active,
						  uint16_t relearn_iteration,
						  uint8_t nb_iteration)
{

    return snprintf((char *)buffer, buffer_size,
                    "%s,%u,%d,%d,%d,%ld.%02ld,%ld.%02ld,%u,%u,l:%d,nl:%d\r\n",
                    product_id,
					(uint8_t)data->similarity,
                    x,
                    y,
                    z,
                    (long)(motor_centi / 100),
                    (long)labs(motor_centi % 100),
                    (long)(ambient_centi / 100),
                    (long)labs(ambient_centi % 100),
                    data->state,
                    data->fault_class,
					relearn_active,
					(relearn_iteration * 100) /nb_iteration);
}
