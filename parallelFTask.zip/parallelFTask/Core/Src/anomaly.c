//Include------
#include "anomaly.h"

//Defines --------
#define ANOMALY_SIMILARITY_THRESHOLD 80.0f
#define ANOMALY_TEMPERATURE_THRESHOLD 30.0f

//Functions----

/**
 * @brief Update system anomaly state based on AI and sensor data.
 * Evaluates similarity, fault class, and temperature to classify
 * system state as NORMAL, WARNING, or CRITICAL.
 */
void anomaly_update(system_data_t *data)
{
    if ((data->similarity >= ANOMALY_SIMILARITY_THRESHOLD) ||
        (data->fault_class == SYSTEM_CLASS_MOTOR_OFF))
    {
        data->state = SYSTEM_STATE_NORMAL;
    }
    else if (data->fault_class == SYSTEM_CLASS_FROTTEMENT)
    {
        data->state = SYSTEM_STATE_CRITICAL;
    }
    else if ((data->fault_class == SYSTEM_CLASS_BALOURD) ||
             (data->fault_class == SYSTEM_CLASS_LOOSE_BELT))
    {
        data->state = SYSTEM_STATE_WARNING;

        if (data->temperature > ANOMALY_TEMPERATURE_THRESHOLD)
        {
            data->state = SYSTEM_STATE_CRITICAL;
        }
    }
    else
    {
        data->state = SYSTEM_STATE_NORMAL;
    }
}
