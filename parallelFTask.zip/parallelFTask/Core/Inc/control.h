#ifndef CONTROL_H
#define CONTROL_H

#ifdef __cplusplus
extern "C" {
#endif

//Includes------
#include "system_data.h"
#include <stdint.h>

void control_init(system_data_t *data);
uint8_t control_update_button(system_data_t *data, uint32_t now_ms);
uint8_t system_is_enabled(void);

#ifdef __cplusplus
}
#endif

#endif /* CONTROL_H */
