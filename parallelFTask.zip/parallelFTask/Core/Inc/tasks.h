#ifndef TASKS_H
#define TASKS_H

#ifdef __cplusplus
extern "C" {
#endif

void acquisition_task(void const * argument);
void ai_task(void const * argument);
void uart_task(void const * argument);
void led_task(void const * argument);
void anomaly_task(void const * argument);
void buzzer_task(void const * argument);

#ifdef __cplusplus
}
#endif

#endif /* TASKS_H */
