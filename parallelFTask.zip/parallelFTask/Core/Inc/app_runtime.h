#ifndef APP_RUNTIME_H
#define APP_RUNTIME_H

#ifdef __cplusplus
extern "C" {
#endif

//Includes --------------
#include "stm32f4xx_hal.h"

//Functions ---------
void app_runtime_init(void);
void app_startup(void);
void app_runtime_apply_system_state(void);
void app_acquisition_process_pending(void);
void app_ai_process_pending(void);
void app_uart_process_pending(void);
void app_led_update(void);
void app_runtime_on_timer_elapsed(TIM_HandleTypeDef *htim);

#ifdef __cplusplus
}
#endif

#endif /* APP_RUNTIME_H */
