#ifndef UART_FORMAT_H
#define UART_FORMAT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "system_data.h"
#include <stddef.h>
#include <stdint.h>

int uart_format_telemetry(uint8_t *buffer,
                          size_t buffer_size,
                          const char *product_id,
                          const system_data_t *data,
                          int16_t x,
                          int16_t y,
                          int16_t z,
                          int32_t motor_centi,
                          int32_t ambient_centi,uint8_t relearn_active,
						  uint16_t relearn_iteration,
						  uint8_t nb_iteration);

#ifdef __cplusplus
}
#endif

#endif /* UART_FORMAT_H */
