#ifndef BUZZER_H
#define BUZZER_H

#ifdef __cplusplus
extern "C" {
#endif

//Includes -------
#include "system_data.h"

//Functions ------

/**
 * @brief Control buzzer state based on system status.
 * Activates buzzer only when system is enabled and in CRITICAL state.
 * @param data Pointer to system data structure.
 */
void buzzer_update(const system_data_t *data);

/**
 * @brief Turn off the buzzer.
 * Forces buzzer GPIO to LOW state.
 */
void buzzer_off(void);

#ifdef __cplusplus
}
#endif

#endif /* BUZZER_H */
