#ifndef SYSTEM_DATA_H
#define SYSTEM_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define SYSTEM_STATE_NORMAL   0U
#define SYSTEM_STATE_WARNING  1U
#define SYSTEM_STATE_CRITICAL 2U

#define SYSTEM_CLASS_BALOURD    0U
#define SYSTEM_CLASS_FROTTEMENT 1U
#define SYSTEM_CLASS_LOOSE_BELT 2U
#define SYSTEM_CLASS_MOTOR_OFF  3U

typedef struct {
    float similarity;
    float temperature;
    uint32_t inference_time_us;
    uint8_t state;
    uint8_t enabled;
    uint8_t fault_class;
} system_data_t;

extern system_data_t system_data;

#ifdef __cplusplus
}
#endif

#endif /* SYSTEM_DATA_H */
