#ifndef ANOMALY_H
#define ANOMALY_H

#ifdef __cplusplus
extern "C" {
#endif

//Include------
#include "system_data.h"

//Functions----

/**
 * @brief Update system anomaly state based on AI and sensor data.
 * Evaluates similarity, fault class, and temperature to classify
 * system state as NORMAL, WARNING, or CRITICAL.
 */
void anomaly_update(system_data_t *data);

#ifdef __cplusplus
}
#endif

#endif /* ANOMALY_H */
