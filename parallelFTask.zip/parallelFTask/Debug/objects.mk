################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

USER_OBJS :=

LIBS := -lneai -l:NetworkRuntime1020_CM4_GCC.a -l:libarm_cortexM4lf_math.a

