Core/Src/control.o: ../Core/Src/control.c ../Core/Inc/control.h \
 ../Core/Inc/system_data.h
../Core/Inc/control.h:
../Core/Inc/system_data.h:
