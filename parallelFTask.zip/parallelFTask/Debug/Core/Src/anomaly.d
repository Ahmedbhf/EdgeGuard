Core/Src/anomaly.o: ../Core/Src/anomaly.c ../Core/Inc/anomaly.h \
 ../Core/Inc/system_data.h
../Core/Inc/anomaly.h:
../Core/Inc/system_data.h:
