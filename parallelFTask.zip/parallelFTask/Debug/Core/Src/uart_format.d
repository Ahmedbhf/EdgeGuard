Core/Src/uart_format.o: ../Core/Src/uart_format.c \
 ../Core/Inc/uart_format.h ../Core/Inc/system_data.h
../Core/Inc/uart_format.h:
../Core/Inc/system_data.h:
